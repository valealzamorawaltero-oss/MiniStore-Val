package dao;

import model.Categoria;
import model.Producto;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO de Productos sobre la tabla "productos" de ministore.
 * Las categorías se leen de la tabla "categorias" (id_categoria, nombre); si esa tabla no
 * existe, se usan los id_categoria que ya aparecen en productos ("Categoría N").
 */
public class ProductoDAO {

    private static final int STOCK_MINIMO_POR_DEFECTO = 5;

    private String ultimoError;

    public String getUltimoError() { return ultimoError; }

    // ── Categorías ───────────────────────────────────────────────
    private Map<Integer, String> cargarCategorias(Connection con) {
        Map<Integer, String> mapa = new LinkedHashMap<Integer, String>();
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id_categoria, nombre FROM categorias ORDER BY id_categoria");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) mapa.put(rs.getInt(1), rs.getString(2));
        } catch (SQLException e) {
            mapa.clear();   // la tabla categorias no existe o tiene otras columnas
        }
        if (mapa.isEmpty()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT DISTINCT id_categoria FROM productos ORDER BY id_categoria");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) mapa.put(rs.getInt(1), "Categoría " + rs.getInt(1));
            } catch (SQLException e) {
                mapa.clear();
            }
        }
        if (mapa.isEmpty()) mapa.put(1, "General");
        return mapa;
    }

    public List<Categoria> getCategorias() {
        List<Categoria> lista = new ArrayList<Categoria>();
        try {
            Map<Integer, String> mapa = cargarCategorias(DBConnection.getConnection());
            for (Map.Entry<Integer, String> e : mapa.entrySet())
                lista.add(new Categoria(e.getKey(), e.getValue()));
            ultimoError = null;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    // ── Consultas ────────────────────────────────────────────────
    private List<Producto> consultar(String where, Object... params) {
        List<Producto> lista = new ArrayList<Producto>();
        String sql = "SELECT id_producto, nombre, descripcion, id_categoria, precio_venta, precio_costo, stock "
                   + "FROM productos WHERE activo = 1 " + where + " ORDER BY id_producto";
        try {
            Connection con = DBConnection.getConnection();
            Map<Integer, String> cats = cargarCategorias(con);
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) ps.setObject(i + 1, params[i]);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int idCat = rs.getInt("id_categoria");
                        String nomCat = cats.containsKey(idCat) ? cats.get(idCat) : "Categoría " + idCat;
                        lista.add(new Producto(rs.getInt("id_producto"), rs.getString("nombre"), idCat, nomCat,
                                rs.getDouble("precio_venta"), rs.getDouble("precio_costo"), rs.getInt("stock"),
                                rs.getString("descripcion")));
                    }
                }
            }
            ultimoError = null;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    public List<Producto> getAll() {
        return consultar("");
    }

    public Producto getById(int id) {
        List<Producto> r = consultar("AND id_producto = ?", id);
        return r.isEmpty() ? null : r.get(0);
    }

    public List<Producto> getByCategoria(int idCategoria) {
        return consultar("AND id_categoria = ?", idCategoria);
    }

    public List<Producto> buscarPorNombre(String texto) {
        return consultar("AND nombre LIKE ?", "%" + texto + "%");
    }

    // ── Escritura ────────────────────────────────────────────────
    public boolean insertar(Producto p) {
        String sql = "INSERT INTO productos (nombre, descripcion, precio_venta, precio_costo, stock, "
                   + "stock_minimo, id_categoria, activo) VALUES (?, ?, ?, ?, ?, ?, ?, 1)";
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, p.getNombre());
                ps.setString(2, p.getDescripcion());   // "" si el usuario no la escribe
                ps.setDouble(3, p.getPrecio());
                ps.setDouble(4, p.getPrecioCosto());
                ps.setInt(5, p.getStock());
                ps.setInt(6, STOCK_MINIMO_POR_DEFECTO);
                ps.setInt(7, p.getIdCategoria());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) p.setId(keys.getInt(1));
                }
            }
            ultimoError = null;
            return true;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public boolean actualizar(Producto p) {
        String sql = "UPDATE productos SET nombre=?, descripcion=?, precio_venta=?, precio_costo=?, stock=?, "
                   + "id_categoria=? WHERE id_producto=?";
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, p.getNombre());
                ps.setString(2, p.getDescripcion());
                ps.setDouble(3, p.getPrecio());
                ps.setDouble(4, p.getPrecioCosto());
                ps.setInt(5, p.getStock());
                ps.setInt(6, p.getIdCategoria());
                ps.setInt(7, p.getId());
                boolean ok = ps.executeUpdate() > 0;
                ultimoError = ok ? null : "Producto no encontrado.";
                return ok;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Elimina el producto; si ya tiene ventas asociadas, lo desactiva (activo = 0). */
    public boolean eliminar(int id) {
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM productos WHERE id_producto=?")) {
                ps.setInt(1, id);
                boolean ok = ps.executeUpdate() > 0;
                ultimoError = ok ? null : "Producto no encontrado.";
                return ok;
            } catch (SQLException e) {
                if (e.getSQLState() != null && e.getSQLState().startsWith("23")) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE productos SET activo = 0 WHERE id_producto=?")) {
                        ps.setInt(1, id);
                        boolean ok = ps.executeUpdate() > 0;
                        ultimoError = ok ? null : "Producto no encontrado.";
                        return ok;
                    }
                }
                throw e;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }
}
