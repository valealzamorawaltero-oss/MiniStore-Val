package dao;

import util.DBConnection;
import util.Sesion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;

public class UsuarioDAO {

    /**
     * Valida usuario y contraseña contra la tabla "usuarios" de ministore.
     * Si son correctos, guarda el usuario en la sesión (util.Sesion) y devuelve su username;
     * si no coinciden, devuelve null. Lanza SQLException si no hay conexión con la base de datos.
     */
    public String autenticar(String username, String password) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE username = ? AND password = ?";
        Connection con = DBConnection.getConnection();
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                String nombre = rs.getString("username");
                Sesion.iniciar(leerId(rs), nombre);
                return nombre;
            }
        }
    }

    /** Lee el id del usuario: columna id_usuario (o id); si no existe, la primera columna numérica. */
    private int leerId(ResultSet rs) throws SQLException {
        for (String col : new String[]{"id_usuario", "id"}) {
            try {
                return rs.getInt(rs.findColumn(col));
            } catch (SQLException e) {
                // la columna no existe; se prueba la siguiente
            }
        }
        ResultSetMetaData md = rs.getMetaData();
        for (int i = 1; i <= md.getColumnCount(); i++) {
            int t = md.getColumnType(i);
            if (t == Types.INTEGER || t == Types.BIGINT || t == Types.SMALLINT || t == Types.TINYINT)
                return rs.getInt(i);
        }
        return -1;
    }
}
