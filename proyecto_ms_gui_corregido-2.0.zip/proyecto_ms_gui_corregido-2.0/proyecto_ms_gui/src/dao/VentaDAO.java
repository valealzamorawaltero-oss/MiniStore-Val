package dao;

import model.ItemVenta;
import model.Venta;
import util.DBConnection;
import util.Sesion;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Locale;
import java.util.List;

/**
 * DAO de Ventas sobre las tablas "ventas" y "detalle_venta" de ministore.
 *   ventas(id_venta, numero_venta, id_cliente, id_usuario, fecha, total)
 *   detalle_venta(id_venta, id_producto, cantidad, precio_unitario, subtotal)
 * Registrar (con varios productos) y eliminar se hacen en una transacción y ajustan el stock de productos.
 */
public class VentaDAO {

    private String ultimoError;

    public String getUltimoError() { return ultimoError; }

    /** Una fila por producto vendido (las ventas de varios productos aparecen en varias filas). */
    public List<Venta> getAll() {
        List<Venta> lista = new ArrayList<Venta>();
        try {
            Connection con = DBConnection.getConnection();
            String colFecha = columnaFecha(con);
            String sql = "SELECT v.id_venta, v.id_cliente, c.nombre AS cliente, d.id_producto, "
                       + "p.nombre AS producto, d.cantidad, COALESCE(d.subtotal, v.total) AS total, "
                       + (colFecha.isEmpty() ? "NULL" : "v.`" + colFecha + "`") + " AS fecha "
                       + "FROM ventas v "
                       + "LEFT JOIN clientes c ON c.id_cliente = v.id_cliente "
                       + "LEFT JOIN detalle_venta d ON d.id_venta = v.id_venta "
                       + "LEFT JOIN productos p ON p.id_producto = d.id_producto "
                       + "ORDER BY v.id_venta DESC";
            try (PreparedStatement ps = con.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Timestamp ts = rs.getTimestamp("fecha");
                    LocalDate fecha = ts != null ? ts.toLocalDateTime().toLocalDate() : LocalDate.now();
                    String producto = rs.getString("producto");
                    lista.add(new Venta(rs.getInt("id_venta"), rs.getInt("id_cliente"),
                            rs.getString("cliente") != null ? rs.getString("cliente") : "(cliente eliminado)",
                            rs.getInt("id_producto"), producto != null ? producto : "(sin detalle)",
                            rs.getInt("cantidad"), rs.getDouble("total"), fecha));
                }
            }
            ultimoError = null;
        } catch (SQLException e) {
            ultimoError = mensaje(e);
        }
        return lista;
    }

    private double ultimoTotal;
    private String ultimoNumeroVenta;

    /** Total de la última venta registrada con éxito. */
    public double getUltimoTotal() { return ultimoTotal; }
    /** Número (numero_venta) de la última venta registrada con éxito. */
    public String getUltimoNumeroVenta() { return ultimoNumeroVenta; }

    /** Registra una venta de un solo producto (usa registrarVenta con un carrito de una línea). */
    public boolean registrar(Venta v) {
        List<ItemVenta> items = new ArrayList<ItemVenta>();
        items.add(new ItemVenta(v.getProductoId(), v.getProductoNombre(), v.getCantidad(), 0));
        int id = registrarVenta(v.getClienteId(), items);
        if (id > 0) {
            v.setId(id);
            v.setTotal(ultimoTotal);
            return true;
        }
        return false;
    }

    /**
     * Registra UNA venta con VARIOS productos. Los precios se toman de la base de datos (no de la
     * pantalla), se valida el stock de cada producto y todo se guarda o nada (transacción).
     * Si un producto aparece repetido en el carrito, se suman sus cantidades.
     * Devuelve el id de la venta, o -1 si falló (ver getUltimoError()).
     */
    public int registrarVenta(int clienteId, List<ItemVenta> items) {
        if (items == null || items.isEmpty()) {
            ultimoError = "La venta no tiene productos.";
            return -1;
        }
        if (!Sesion.activa()) {
            ultimoError = "No hay un usuario con sesión iniciada (id_usuario). Cierra el programa e inicia sesión de nuevo.";
            return -1;
        }

        // Une productos repetidos y ordena por id (así los bloqueos siempre van en el mismo orden)
        TreeMap<Integer, Integer> cantidades = new TreeMap<Integer, Integer>();
        for (ItemVenta it : items) {
            if (it.getCantidad() <= 0) {
                ultimoError = "La cantidad de \"" + it.getProductoNombre() + "\" debe ser mayor a 0.";
                return -1;
            }
            Integer previa = cantidades.get(it.getProductoId());
            cantidades.put(it.getProductoId(), (previa == null ? 0 : previa) + it.getCantidad());
        }

        Connection con = null;
        boolean autoPrevio = true;
        try {
            con = DBConnection.getConnection();
            autoPrevio = con.getAutoCommit();
            con.setAutoCommit(false);

            // 1. Productos: precio y stock actuales (bloqueados hasta terminar)
            List<Object[]> lineas = new ArrayList<Object[]>();   // {id, nombre, precio, cantidad, subtotal}
            BigDecimal total = BigDecimal.ZERO;
            for (Map.Entry<Integer, Integer> e : cantidades.entrySet()) {
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT nombre, precio_venta, stock FROM productos "
                      + "WHERE id_producto = ? AND activo = 1 FOR UPDATE")) {
                    ps.setInt(1, e.getKey());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Un producto del carrito no existe o está inactivo (id " + e.getKey() + ").");
                        String nombre = rs.getString("nombre");
                        BigDecimal precio = rs.getBigDecimal("precio_venta");
                        if (rs.getInt("stock") < e.getValue())
                            throw new SQLException("Stock insuficiente de \"" + nombre
                                    + "\" (pides " + e.getValue() + ", disponible: " + rs.getInt("stock") + ").");
                        BigDecimal subtotal = precio.multiply(new BigDecimal(e.getValue()));
                        total = total.add(subtotal);
                        lineas.add(new Object[]{e.getKey(), nombre, precio, e.getValue(), subtotal});
                    }
                }
            }

            // 2. Número de venta consecutivo
            String numeroVenta;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COALESCE(MAX(CAST(numero_venta AS UNSIGNED)), 0) + 1 FROM ventas");
                 ResultSet rs = ps.executeQuery()) {
                rs.next();
                numeroVenta = rs.getString(1);
            }

            // 3. Cabecera (las columnas obligatorias que no conocemos se rellenan según la estructura real)
            LinkedHashMap<String, Object> cab = new LinkedHashMap<String, Object>();
            cab.put("numero_venta", numeroVenta);
            cab.put("id_cliente", clienteId);
            cab.put("id_usuario", Sesion.getUsuarioId());
            cab.put("total", total);
            String colFecha = columnaFecha(con);
            if (!colFecha.isEmpty()) cab.put(colFecha, AHORA);
            int idVenta = insertarFila(con, "ventas", cab, total);

            // 4. Un renglón de detalle por producto + descuento de stock
            for (Object[] l : lineas) {
                LinkedHashMap<String, Object> det = new LinkedHashMap<String, Object>();
                det.put("id_venta", idVenta);
                det.put("id_producto", l[0]);
                det.put("cantidad", l[3]);
                det.put("precio_unitario", l[2]);
                det.put("subtotal", l[4]);
                insertarFila(con, "detalle_venta", det, (BigDecimal) l[4]);

                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE productos SET stock = stock - ? WHERE id_producto = ?")) {
                    ps.setInt(1, (Integer) l[3]);
                    ps.setInt(2, (Integer) l[0]);
                    ps.executeUpdate();
                }
            }

            con.commit();
            ultimoTotal = total.doubleValue();
            ultimoNumeroVenta = numeroVenta;
            ultimoError = null;
            return idVenta;

        } catch (SQLException e) {
            rollback(con);
            ultimoError = mensaje(e);
            return -1;
        } finally {
            restaurarAutoCommit(con, autoPrevio);
        }
    }

    /** Elimina la venta, devuelve el stock de sus productos y borra su detalle. */
    public boolean eliminar(int idVenta) {
        Connection con = null;
        boolean autoPrevio = true;
        try {
            con = DBConnection.getConnection();
            autoPrevio = con.getAutoCommit();
            con.setAutoCommit(false);

            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE productos p JOIN detalle_venta d ON d.id_producto = p.id_producto "
                  + "SET p.stock = p.stock + d.cantidad WHERE d.id_venta = ?")) {
                ps.setInt(1, idVenta);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM detalle_venta WHERE id_venta = ?")) {
                ps.setInt(1, idVenta);
                ps.executeUpdate();
            }
            int filas;
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM ventas WHERE id_venta = ?")) {
                ps.setInt(1, idVenta);
                filas = ps.executeUpdate();
            }
            if (filas == 0) throw new SQLException("Venta no encontrada.");

            con.commit();
            ultimoError = null;
            return true;

        } catch (SQLException e) {
            rollback(con);
            ultimoError = mensaje(e);
            return false;
        } finally {
            restaurarAutoCommit(con, autoPrevio);
        }
    }

    public double getTotalVentas() {
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement("SELECT COALESCE(SUM(total), 0) FROM ventas");
                 ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0;
            }
        } catch (SQLException e) {
            ultimoError = mensaje(e);
            return 0;
        }
    }

    private void rollback(Connection con) {
        if (con != null) {
            try { con.rollback(); } catch (SQLException ignorado) { }
        }
    }

    private void restaurarAutoCommit(Connection con, boolean valor) {
        if (con != null) {
            try { con.setAutoCommit(valor); } catch (SQLException ignorado) { }
        }
    }

    // ── Detección de columnas (la estructura real de tu base de datos) ─────────
    private String columnaFecha;   // cache; "" = la tabla ventas no tiene columna de fecha

    /** Nombre de la columna de fecha de la tabla ventas (fecha, fecha_venta, fecha_registro...). */
    private String columnaFecha(Connection con) throws SQLException {
        if (columnaFecha != null) return columnaFecha;
        List<String> nombres = new ArrayList<String>();
        List<Integer> tipos = new ArrayList<Integer>();
        try (ResultSet rs = con.getMetaData().getColumns(con.getCatalog(), null, "ventas", "%")) {
            while (rs.next()) {
                nombres.add(rs.getString("COLUMN_NAME"));
                tipos.add(rs.getInt("DATA_TYPE"));
            }
        }
        String elegida = "";
        String[] preferidas = {"fecha", "fecha_venta", "fecha_registro", "fecha_creacion", "created_at"};
        for (String pref : preferidas) {
            for (String n : nombres) if (n.equalsIgnoreCase(pref)) { elegida = n; break; }
            if (!elegida.isEmpty()) break;
        }
        if (elegida.isEmpty()) {
            for (String n : nombres)
                if (n.toLowerCase(Locale.ROOT).contains("fecha")) { elegida = n; break; }
        }
        if (elegida.isEmpty()) {
            for (int i = 0; i < nombres.size(); i++) {
                int t = tipos.get(i);
                if (t == java.sql.Types.TIMESTAMP || t == java.sql.Types.DATE) { elegida = nombres.get(i); break; }
            }
        }
        if (elegida.indexOf('`') >= 0) elegida = "";
        columnaFecha = elegida;
        return columnaFecha;
    }

    private String columnasDe(Connection con, String tabla) {
        StringBuilder sb = new StringBuilder();
        try (ResultSet rs = con.getMetaData().getColumns(con.getCatalog(), null, tabla, "%")) {
            while (rs.next()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(rs.getString("COLUMN_NAME"));
            }
        } catch (SQLException ignorado) { }
        return sb.length() == 0 ? "(la tabla no existe)" : sb.toString();
    }

    /** Mensaje del error; si falta una columna, añade las columnas reales de las tablas de ventas. */
    private String mensaje(SQLException e) {
        String m = e.getMessage();
        if ("42S22".equals(e.getSQLState())) {
            try {
                Connection con = DBConnection.getConnection();
                m += "\n\nColumnas reales en tu base de datos:\n  ventas: " + columnasDe(con, "ventas")
                   + "\n  detalle_venta: " + columnasDe(con, "detalle_venta");
            } catch (SQLException ignorado) { }
        }
        return m;
    }

    // ── Inserción adaptable a la estructura real de las tablas ────────────────
    private static final Object AHORA = new Object();   // marcador: usar NOW() en la fecha

    private static class Col {
        String nombre, tipoNombre;
        int tipo;
        boolean obligatoria;    // NOT NULL, sin valor por defecto y no autoincremental
    }

    private List<Col> describir(Connection con, String tabla) throws SQLException {
        List<Col> cols = new ArrayList<Col>();
        try (ResultSet rs = con.getMetaData().getColumns(con.getCatalog(), null, tabla, "%")) {
            while (rs.next()) {
                Col c = new Col();
                c.nombre = rs.getString("COLUMN_NAME");
                c.tipo = rs.getInt("DATA_TYPE");
                c.tipoNombre = rs.getString("TYPE_NAME");
                boolean noNula = "NO".equalsIgnoreCase(rs.getString("IS_NULLABLE"));
                boolean sinDefecto = rs.getString("COLUMN_DEF") == null;
                boolean auto = "YES".equalsIgnoreCase(rs.getString("IS_AUTOINCREMENT"));
                String generada = rs.getString("IS_GENERATEDCOLUMN");
                c.obligatoria = noNula && sinDefecto && !auto && !"YES".equalsIgnoreCase(generada);
                cols.add(c);
            }
        }
        return cols;
    }

    /**
     * Inserta una fila con los valores dados y devuelve el id generado (o 0). Si la tabla tiene
     * otras columnas obligatorias sin valor por defecto (subtotal, descuento, impuesto, estado...),
     * las rellena con un valor neutro para no fallar.
     */
    private int insertarFila(Connection con, String tabla, LinkedHashMap<String, Object> valores,
                             BigDecimal total) throws SQLException {
        LinkedHashMap<String, Object> todos = new LinkedHashMap<String, Object>(valores);
        for (Col c : describir(con, tabla)) {
            boolean yaEsta = false;
            for (String k : valores.keySet()) if (k.equalsIgnoreCase(c.nombre)) yaEsta = true;
            if (!yaEsta && c.obligatoria) todos.put(c.nombre, valorNeutro(con, tabla, c, total));
        }

        StringBuilder cols = new StringBuilder(), marcas = new StringBuilder();
        List<Object> params = new ArrayList<Object>();
        for (Map.Entry<String, Object> e : todos.entrySet()) {
            if (cols.length() > 0) { cols.append(", "); marcas.append(", "); }
            cols.append('`').append(e.getKey().replace("`", "")).append('`');
            if (e.getValue() == AHORA) {
                marcas.append("NOW()");
            } else {
                marcas.append('?');
                params.add(e.getValue());
            }
        }
        String sql = "INSERT INTO " + tabla + " (" + cols + ") VALUES (" + marcas + ")";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            ps.executeUpdate();
            try (ResultSet k = ps.getGeneratedKeys()) {
                return k.next() ? k.getInt(1) : 0;
            }
        }
    }

    /** Valor razonable para una columna obligatoria que el programa no maneja. */
    private Object valorNeutro(Connection con, String tabla, Col c, BigDecimal total) throws SQLException {
        String n = c.nombre.toLowerCase(Locale.ROOT);
        if (n.contains("subtotal") || n.equals("total_bruto") || n.equals("valor_total") || n.equals("monto"))
            return total;                                                   // sin impuestos ni descuentos
        switch (c.tipo) {
            case java.sql.Types.DATE: case java.sql.Types.TIMESTAMP: case java.sql.Types.TIME:
                return AHORA;
            case java.sql.Types.INTEGER: case java.sql.Types.BIGINT: case java.sql.Types.SMALLINT:
            case java.sql.Types.TINYINT: case java.sql.Types.BIT: case java.sql.Types.BOOLEAN:
                return (n.contains("activo") || n.contains("estado")) ? 1 : 0;
            case java.sql.Types.DECIMAL: case java.sql.Types.NUMERIC: case java.sql.Types.DOUBLE:
            case java.sql.Types.FLOAT: case java.sql.Types.REAL:
                return BigDecimal.ZERO;                                     // descuento, impuesto, iva...
            default:
                break;
        }
        if ("ENUM".equalsIgnoreCase(c.tipoNombre)) {
            String op = primeraOpcionEnum(con, tabla, c.nombre);
            if (op != null) return op;
        }
        if (n.contains("metodo") || n.contains("pago")) return "Efectivo";
        if (n.contains("estado")) return "Completada";
        return "";
    }

    /** Para columnas ENUM: elige una opción (prefiere "completada/pagada" si existe, si no la primera). */
    private String primeraOpcionEnum(Connection con, String tabla, String columna) {
        String sql = "SELECT COLUMN_TYPE FROM information_schema.COLUMNS "
                   + "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, tabla);
            ps.setString(2, columna);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("'((?:[^']|'')*)'").matcher(rs.getString(1));
                String primera = null;
                while (m.find()) {
                    String o = m.group(1).replace("''", "'");
                    if (primera == null) primera = o;
                    String l = o.toLowerCase(Locale.ROOT);
                    String c = columna.toLowerCase(Locale.ROOT);
                    boolean esPago = c.contains("metodo") || c.contains("pago");
                    if (esPago && l.contains("efectivo")) return o;
                    if (!esPago && (l.contains("complet") || l.contains("pagad") || l.contains("finaliz"))) return o;
                }
                return primera;
            }
        } catch (SQLException e) {
            return null;
        }
    }
}
