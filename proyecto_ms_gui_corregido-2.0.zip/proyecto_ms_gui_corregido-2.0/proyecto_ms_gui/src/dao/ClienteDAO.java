package dao;

import model.Cliente;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO de Clientes sobre la tabla "clientes" de ministore.
 * Equivalencias: email = columna "correo", id = "id_cliente".
 * Si falla una operación, el motivo queda en getUltimoError().
 */
public class ClienteDAO {

    private static final String COLUMNAS =
        "id_cliente, nombre, documento, correo, telefono, direccion";

    private String ultimoError;

    public String getUltimoError() { return ultimoError; }

    private Cliente mapear(ResultSet rs) throws SQLException {
        return new Cliente(rs.getInt("id_cliente"), rs.getString("nombre"), rs.getString("documento"),
                rs.getString("correo"), rs.getString("telefono"), rs.getString("direccion"));
    }

    private List<Cliente> consultar(String where, String... params) {
        List<Cliente> lista = new ArrayList<Cliente>();
        String sql = "SELECT " + COLUMNAS + " FROM clientes WHERE activo = 1 " + where + " ORDER BY id_cliente";
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) ps.setString(i + 1, params[i]);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) lista.add(mapear(rs));
                }
            }
            ultimoError = null;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    public List<Cliente> getAll() {
        return consultar("");
    }

    public Cliente getById(int id) {
        List<Cliente> r = consultar("AND id_cliente = ?", String.valueOf(id));
        return r.isEmpty() ? null : r.get(0);
    }

    public List<Cliente> buscarPorNombre(String texto) {
        String like = "%" + texto + "%";
        return consultar("AND (nombre LIKE ? OR documento LIKE ?)", like, like);
    }

    public boolean insertar(Cliente c) {
        String sql = "INSERT INTO clientes (nombre, documento, direccion, telefono, correo, activo) "
                   + "VALUES (?, ?, ?, ?, ?, 1)";
        try {
            Connection con = DBConnection.getConnection();
            if (documentoExiste(con, c.getDocumento(), -1)) {
                ultimoError = "Ya existe un cliente con ese documento.";
                return false;
            }
            try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getDocumento());
                ps.setString(3, c.getDireccion());
                ps.setString(4, c.getTelefono());
                ps.setString(5, c.getEmail());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) c.setId(keys.getInt(1));
                }
            }
            ultimoError = null;
            return true;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public boolean actualizar(Cliente c) {
        String sql = "UPDATE clientes SET nombre=?, documento=?, direccion=?, telefono=?, correo=? "
                   + "WHERE id_cliente=?";
        try {
            Connection con = DBConnection.getConnection();
            if (documentoExiste(con, c.getDocumento(), c.getId())) {
                ultimoError = "Ya existe otro cliente con ese documento.";
                return false;
            }
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, c.getNombre());
                ps.setString(2, c.getDocumento());
                ps.setString(3, c.getDireccion());
                ps.setString(4, c.getTelefono());
                ps.setString(5, c.getEmail());
                ps.setInt(6, c.getId());
                boolean ok = ps.executeUpdate() > 0;
                ultimoError = ok ? null : "Cliente no encontrado.";
                return ok;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /**
     * Elimina el cliente. Si ya tiene ventas registradas (la base de datos no permite
     * borrarlo), se desactiva (activo = 0) para conservar el historial.
     */
    public boolean eliminar(int id) {
        try {
            Connection con = DBConnection.getConnection();
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM clientes WHERE id_cliente=?")) {
                ps.setInt(1, id);
                boolean ok = ps.executeUpdate() > 0;
                ultimoError = ok ? null : "Cliente no encontrado.";
                return ok;
            } catch (SQLException e) {
                if (e.getSQLState() != null && e.getSQLState().startsWith("23")) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "UPDATE clientes SET activo = 0 WHERE id_cliente=?")) {
                        ps.setInt(1, id);
                        boolean ok = ps.executeUpdate() > 0;
                        ultimoError = ok ? null : "Cliente no encontrado.";
                        return ok;
                    }
                }
                throw e;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    private boolean documentoExiste(Connection con, String documento, int excluirId) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT 1 FROM clientes WHERE documento = ? AND id_cliente <> ?")) {
            ps.setString(1, documento);
            ps.setInt(2, excluirId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }
}
