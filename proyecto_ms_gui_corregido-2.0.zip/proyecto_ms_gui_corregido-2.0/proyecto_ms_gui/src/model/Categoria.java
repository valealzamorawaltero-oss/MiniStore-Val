package model;

public class Categoria {
    private final int id;
    private final String nombre;

    public Categoria(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId()        { return id; }
    public String getNombre() { return nombre; }

    @Override public String toString() { return nombre; }

    @Override public boolean equals(Object o) {
        return o instanceof Categoria && ((Categoria) o).id == id;
    }

    @Override public int hashCode() { return id; }
}
