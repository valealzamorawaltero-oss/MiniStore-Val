package model;

public class Cliente {
    private int id;
    private String nombre;
    private String documento;
    private String email;
    private String telefono;
    private String direccion;

    public Cliente() {}

    public Cliente(int id, String nombre, String documento, String email, String telefono, String direccion) {
        this.id = id;
        this.nombre = nombre;
        this.documento = documento;
        this.email = email;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public int getId()           { return id; }
    public String getNombre()    { return nombre; }
    public String getDocumento() { return documento; }
    public String getEmail()     { return email; }
    public String getTelefono()  { return telefono; }
    public String getDireccion() { return direccion; }

    public void setId(int id)              { this.id = id; }
    public void setNombre(String n)        { this.nombre = n; }
    public void setDocumento(String d)     { this.documento = d; }
    public void setEmail(String e)         { this.email = e; }
    public void setTelefono(String t)      { this.telefono = t; }
    public void setDireccion(String d)     { this.direccion = d; }

    @Override public String toString() { return nombre; }
}
