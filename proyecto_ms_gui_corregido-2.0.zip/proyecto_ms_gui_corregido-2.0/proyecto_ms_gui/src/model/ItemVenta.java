package model;

/** Una línea del carrito: un producto con su cantidad. */
public class ItemVenta {
    private final int productoId;
    private final String productoNombre;
    private int cantidad;
    private final double precio;     // precio unitario mostrado (el definitivo se toma de la base de datos)

    public ItemVenta(int productoId, String productoNombre, int cantidad, double precio) {
        this.productoId = productoId;
        this.productoNombre = productoNombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public int getProductoId()        { return productoId; }
    public String getProductoNombre() { return productoNombre; }
    public int getCantidad()          { return cantidad; }
    public double getPrecio()         { return precio; }
    public double getSubtotal()       { return precio * cantidad; }

    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
}
