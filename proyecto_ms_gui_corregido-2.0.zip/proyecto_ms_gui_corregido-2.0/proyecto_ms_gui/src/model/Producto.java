package model;

public class Producto {
    private int id;
    private String nombre;
    private String descripcion = "";   // opcional
    private int idCategoria;
    private String categoria;
    private double precio;        // precio_venta
    private double precioCosto;   // precio_costo
    private int stock;

    public Producto() {}

    public Producto(int id, String nombre, int idCategoria, String categoria,
                    double precio, double precioCosto, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.idCategoria = idCategoria;
        this.categoria = categoria;
        this.precio = precio;
        this.precioCosto = precioCosto;
        this.stock = stock;
    }

    public Producto(int id, String nombre, int idCategoria, String categoria,
                    double precio, double precioCosto, int stock, String descripcion) {
        this(id, nombre, idCategoria, categoria, precio, precioCosto, stock);
        setDescripcion(descripcion);
    }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String d) { this.descripcion = d == null ? "" : d; }

    public int getId()           { return id; }
    public String getNombre()    { return nombre; }
    public int getIdCategoria()  { return idCategoria; }
    public String getCategoria() { return categoria; }
    public double getPrecio()    { return precio; }
    public double getPrecioCosto() { return precioCosto; }
    public int getStock()        { return stock; }

    public void setId(int id)              { this.id = id; }
    public void setNombre(String n)        { this.nombre = n; }
    public void setIdCategoria(int c)      { this.idCategoria = c; }
    public void setCategoria(String c)     { this.categoria = c; }
    public void setPrecio(double p)        { this.precio = p; }
    public void setPrecioCosto(double p)   { this.precioCosto = p; }
    public void setStock(int s)            { this.stock = s; }

    @Override public String toString() { return nombre; }
}
