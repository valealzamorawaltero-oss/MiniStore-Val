package model;

import java.time.LocalDate;

public class Venta {
    private int id;
    private int clienteId;
    private String clienteNombre;
    private int productoId;
    private String productoNombre;
    private int cantidad;
    private double total;
    private LocalDate fecha;

    public Venta() {}

    public Venta(int id, int clienteId, String clienteNombre,
                 int productoId, String productoNombre,
                 int cantidad, double total, LocalDate fecha) {
        this.id = id;
        this.clienteId = clienteId;
        this.clienteNombre = clienteNombre;
        this.productoId = productoId;
        this.productoNombre = productoNombre;
        this.cantidad = cantidad;
        this.total = total;
        this.fecha = fecha;
    }

    public int getId()               { return id; }
    public int getClienteId()        { return clienteId; }
    public String getClienteNombre() { return clienteNombre; }
    public int getProductoId()       { return productoId; }
    public String getProductoNombre(){ return productoNombre; }
    public int getCantidad()         { return cantidad; }
    public double getTotal()         { return total; }
    public LocalDate getFecha()      { return fecha; }

    public void setId(int id)                     { this.id = id; }
    public void setClienteId(int cId)             { this.clienteId = cId; }
    public void setClienteNombre(String cn)       { this.clienteNombre = cn; }
    public void setProductoId(int pId)            { this.productoId = pId; }
    public void setProductoNombre(String pn)      { this.productoNombre = pn; }
    public void setCantidad(int c)                { this.cantidad = c; }
    public void setTotal(double t)                { this.total = t; }
    public void setFecha(LocalDate f)             { this.fecha = f; }
}
