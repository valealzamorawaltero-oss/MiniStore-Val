package gui;

import dao.ClienteDAO;
import model.Cliente;
import util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class ClientesPanel extends JPanel {

    private ClienteDAO dao = new ClienteDAO();
    private DefaultTableModel tableModel;
    private JTable tabla;
    private JTextField txtBuscar, txtNombre, txtDocumento, txtEmail, txtTelefono, txtDireccion;
    private JLabel lblStatus;
    private int selectedId = -1;

    public ClientesPanel() {
        setOpaque(false);
        setBackground(UITheme.BG_DARK);
        setLayout(new BorderLayout(0, 0));
        initUI();
        cargarTabla(dao.getAll());
        avisarSiHayError();
    }

    private void initUI() {
        // ── Barra superior ────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout(12, 0));
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(16, 24, 12, 24));

        txtBuscar = UITheme.styledField("Buscar cliente…");
        txtBuscar.setPreferredSize(new Dimension(260, 36));
        txtBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { filtrar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { filtrar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filtrar(); }
        });

        JButton btnNuevo = UITheme.primaryButton("+ Nuevo Cliente");
        btnNuevo.addActionListener(e -> limpiarFormulario());

        topBar.add(txtBuscar, BorderLayout.WEST);
        topBar.add(btnNuevo, BorderLayout.EAST);

        // ── Tabla ─────────────────────────────────────────────────
        String[] cols = {"ID", "Nombre", "Documento", "Email", "Teléfono", "Dirección"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(tableModel);
        UITheme.styleTable(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                selectedId    = (int) tableModel.getValueAt(row, 0);
                txtNombre.setText((String) tableModel.getValueAt(row, 1));
                txtDocumento.setText((String) tableModel.getValueAt(row, 2));
                txtEmail.setText((String) tableModel.getValueAt(row, 3));
                txtTelefono.setText((String) tableModel.getValueAt(row, 4));
                txtDireccion.setText((String) tableModel.getValueAt(row, 5));
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setOpaque(false);
        scroll.getViewport().setBackground(UITheme.BG_CARD);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, UITheme.BORDER));

        // ── Panel derecho: formulario ─────────────────────────────
        JPanel formPanel = new JPanel();
        formPanel.setOpaque(false);
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setPreferredSize(new Dimension(280, 0));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, UITheme.BORDER),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel formTitle = new JLabel("Datos del Cliente");
        formTitle.setFont(UITheme.FONT_SUBTITLE);
        formTitle.setForeground(UITheme.TEXT_PRIMARY);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtNombre    = UITheme.styledField("Nombre completo");
        txtDocumento = UITheme.styledField("Número de documento");
        txtEmail     = UITheme.styledField("correo@ejemplo.com");
        txtTelefono  = UITheme.styledField("Teléfono");
        txtDireccion = UITheme.styledField("Dirección");

        JTextField[] fields = {txtNombre, txtDocumento, txtEmail, txtTelefono, txtDireccion};
        String[] labels     = {"Nombre", "Documento", "Email", "Teléfono", "Dirección"};
        for (JTextField f : fields) {
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        JButton btnGuardar  = UITheme.primaryButton("💾  Guardar");
        JButton btnEliminar = UITheme.dangerButton("🗑  Eliminar");
        JButton btnLimpiar  = new JButton("✖  Cancelar");
        btnLimpiar.setFont(UITheme.FONT_BODY);
        btnLimpiar.setForeground(UITheme.TEXT_MUTED);
        btnLimpiar.setOpaque(false);
        btnLimpiar.setContentAreaFilled(false);
        btnLimpiar.setBorderPainted(false);
        btnLimpiar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnGuardar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnGuardar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnEliminar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnEliminar.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLimpiar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btnLimpiar.setAlignmentX(Component.LEFT_ALIGNMENT);

        lblStatus = new JLabel(" ");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnGuardar.addActionListener(e -> guardar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiarFormulario());

        formPanel.add(formTitle);
        formPanel.add(Box.createVerticalStrut(16));
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(UITheme.FONT_SMALL);
            lbl.setForeground(UITheme.TEXT_MUTED);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(lbl);
            formPanel.add(Box.createVerticalStrut(3));
            formPanel.add(fields[i]);
            formPanel.add(Box.createVerticalStrut(10));
        }
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnGuardar);
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnEliminar);
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnLimpiar);
        formPanel.add(Box.createVerticalStrut(8));
        formPanel.add(lblStatus);
        formPanel.add(Box.createVerticalGlue());

        // ── Ensamblar layout ──────────────────────────────────────
        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(scroll, BorderLayout.CENTER);
        center.add(formPanel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    // ── Operaciones ───────────────────────────────────────────────
    private void cargarTabla(List<Cliente> lista) {
        tableModel.setRowCount(0);
        for (Cliente c : lista)
            tableModel.addRow(new Object[]{c.getId(), c.getNombre(), c.getDocumento(), c.getEmail(), c.getTelefono(), c.getDireccion()});
    }

    private void filtrar() {
        String texto = txtBuscar.getText().trim();
        cargarTabla(texto.isEmpty() ? dao.getAll() : dao.buscarPorNombre(texto));
    }

    private void guardar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) { status("⚠ El nombre es obligatorio", UITheme.WARNING); return; }

        String documento = txtDocumento.getText().trim();
        if (documento.isEmpty()) { status("⚠ El documento es obligatorio", UITheme.WARNING); return; }

        Cliente c = new Cliente(selectedId, nombre, documento,
            txtEmail.getText().trim(), txtTelefono.getText().trim(), txtDireccion.getText().trim());

        boolean ok = selectedId < 0 ? dao.insertar(c) : dao.actualizar(c);
        if (ok) {
            status(selectedId < 0 ? "✓ Cliente creado" : "✓ Cliente actualizado", UITheme.SUCCESS);
            cargarTabla(dao.getAll());
            limpiarFormulario();
        } else {
            status("✗ " + dao.getUltimoError(), UITheme.DANGER);
        }
    }

    private void eliminar() {
        if (selectedId < 0) { status("⚠ Selecciona un cliente", UITheme.WARNING); return; }
        int confirm = JOptionPane.showConfirmDialog(this,
            "¿Eliminar el cliente seleccionado?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION && dao.eliminar(selectedId)) {
            status("✓ Cliente eliminado", UITheme.DANGER);
            cargarTabla(dao.getAll());
            limpiarFormulario();
        } else if (confirm == JOptionPane.YES_OPTION) {
            status("✗ " + dao.getUltimoError(), UITheme.DANGER);
        }
    }

    private void limpiarFormulario() {
        selectedId = -1;
        txtNombre.setText(""); txtDocumento.setText(""); txtEmail.setText("");
        txtTelefono.setText(""); txtDireccion.setText("");
        tabla.clearSelection();
        status(" ", UITheme.TEXT_MUTED);
    }

    private void avisarSiHayError() {
        if (dao.getUltimoError() != null)
            JOptionPane.showMessageDialog(this, "No se pudieron cargar los clientes:\n" + dao.getUltimoError(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }

    private void status(String msg, Color color) {
        lblStatus.setText(msg);
        lblStatus.setForeground(color);
    }
}
