package gui;

import util.UITheme;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private JPanel contentPanel;
    private CardLayout cardLayout;
    private String currentUser;
    private JLabel lblCurrentSection;

    // Paneles de sección
    private ClientesPanel clientesPanel;
    private ProductosPanel productosPanel;
    private VentasPanel ventasPanel;

    public MainFrame(String usuario) {
        this.currentUser = usuario;
        setTitle("Sistema de Gestión MS");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 700);
        setMinimumSize(new Dimension(900, 600));
        initUI();
        setLocationRelativeTo(null);
    }

    private void initUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG_DARK);

        add(buildSidebar(), BorderLayout.WEST);
        add(buildContent(), BorderLayout.CENTER);
    }

    // ── Sidebar ──────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(UITheme.BG_PANEL);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(UITheme.BORDER);
                g2.drawLine(getWidth()-1, 0, getWidth()-1, getHeight());
                g2.dispose();
            }
        };
        sidebar.setOpaque(false);
        sidebar.setLayout(new BorderLayout());
        sidebar.setPreferredSize(new Dimension(220, 0));

        // Logo
        JPanel logoArea = new JPanel(new FlowLayout(FlowLayout.CENTER));
        logoArea.setOpaque(false);
        logoArea.setBorder(BorderFactory.createEmptyBorder(24, 0, 16, 0));
        JLabel logoIcon = new JLabel("🛒");
        logoIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 30));
        JLabel logoText = new JLabel("Sistema MS");
        logoText.setFont(UITheme.FONT_SUBTITLE);
        logoText.setForeground(UITheme.TEXT_PRIMARY);
        JPanel logoRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        logoRow.setOpaque(false);
        logoRow.add(logoIcon);
        logoRow.add(logoText);
        logoArea.add(logoRow);

        // Divisor
        JSeparator sep = new JSeparator();
        sep.setForeground(UITheme.BORDER);
        sep.setBackground(UITheme.BORDER);

        // Menú de navegación
        JPanel navMenu = new JPanel();
        navMenu.setOpaque(false);
        navMenu.setLayout(new BoxLayout(navMenu, BoxLayout.Y_AXIS));
        navMenu.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JLabel navLabel = new JLabel("MENÚ PRINCIPAL");
        navLabel.setFont(UITheme.FONT_SMALL);
        navLabel.setForeground(UITheme.TEXT_MUTED);
        navLabel.setBorder(BorderFactory.createEmptyBorder(0, 8, 10, 0));
        navMenu.add(navLabel);

        String[][] menuItems = {
            {"👥", "Clientes",   "CLIENTES"},
            {"📦", "Productos",  "PRODUCTOS"},
            {"💰", "Ventas",     "VENTAS"},
        };

        ButtonGroup bg = new ButtonGroup();
        for (String[] item : menuItems) {
            JToggleButton btn = createNavButton(item[0], item[1], item[2]);
            bg.add(btn);
            navMenu.add(btn);
            navMenu.add(Box.createVerticalStrut(4));
        }

        // Panel inferior: usuario + cerrar sesión
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER),
            BorderFactory.createEmptyBorder(12, 12, 16, 12)
        ));

        JPanel userInfo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        userInfo.setOpaque(false);
        JLabel avatar = new JLabel("👤");
        avatar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        JLabel userName = new JLabel(currentUser);
        userName.setFont(UITheme.FONT_BODY);
        userName.setForeground(UITheme.TEXT_PRIMARY);
        userInfo.add(avatar);
        userInfo.add(userName);

        JButton btnLogout = new JButton("Salir");
        btnLogout.setFont(UITheme.FONT_SMALL);
        btnLogout.setForeground(UITheme.TEXT_MUTED);
        btnLogout.setOpaque(false);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        bottomPanel.add(userInfo, BorderLayout.CENTER);
        bottomPanel.add(btnLogout, BorderLayout.SOUTH);

        sidebar.add(logoArea, BorderLayout.NORTH);
        JPanel topNav = new JPanel(new BorderLayout());
        topNav.setOpaque(false);
        topNav.add(sep, BorderLayout.NORTH);
        topNav.add(navMenu, BorderLayout.CENTER);
        sidebar.add(topNav, BorderLayout.CENTER);
        sidebar.add(bottomPanel, BorderLayout.SOUTH);

        return sidebar;
    }

    private JToggleButton createNavButton(String icon, String text, String card) {
        JToggleButton btn = new JToggleButton(icon + "  " + text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (isSelected()) {
                    g2.setColor(new Color(99, 102, 241, 40));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                    g2.setColor(UITheme.ACCENT);
                    g2.fillRoundRect(0, 6, 3, getHeight()-12, 3, 3);
                } else if (getModel().isRollover()) {
                    g2.setColor(new Color(255, 255, 255, 10));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(UITheme.FONT_BODY);
        btn.setForeground(UITheme.TEXT_MUTED);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btn.setPreferredSize(new Dimension(196, 42));
        btn.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));

        btn.addActionListener(e -> {
            btn.setForeground(UITheme.TEXT_PRIMARY);
            cardLayout.show(contentPanel, card);
            lblCurrentSection.setText(text);
            // Resetear color de otros botones
            Container parent = btn.getParent();
            for (Component c : parent.getComponents()) {
                if (c instanceof JToggleButton && c != btn)
                    ((JToggleButton)c).setForeground(UITheme.TEXT_MUTED);
            }
        });

        return btn;
    }

    // ── Panel de contenido principal ──────────────────────────────
    private JPanel buildContent() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBackground(UITheme.BG_DARK);

        // Header de sección
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER),
            BorderFactory.createEmptyBorder(18, 24, 18, 24)
        ));

        lblCurrentSection = new JLabel("Bienvenido al Sistema MS");
        lblCurrentSection.setFont(UITheme.FONT_TITLE);
        lblCurrentSection.setForeground(UITheme.TEXT_PRIMARY);

        JLabel lblUser = new JLabel("Usuario: " + currentUser);
        lblUser.setFont(UITheme.FONT_SMALL);
        lblUser.setForeground(UITheme.TEXT_MUTED);

        header.add(lblCurrentSection, BorderLayout.WEST);
        header.add(lblUser, BorderLayout.EAST);

        // Paneles con CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false);
        contentPanel.setBackground(UITheme.BG_DARK);

        clientesPanel   = new ClientesPanel();
        productosPanel  = new ProductosPanel();
        ventasPanel     = new VentasPanel();

        contentPanel.add(buildWelcomePanel(), "WELCOME");
        contentPanel.add(clientesPanel,       "CLIENTES");
        contentPanel.add(productosPanel,      "PRODUCTOS");
        contentPanel.add(ventasPanel,         "VENTAS");

        cardLayout.show(contentPanel, "WELCOME");

        wrapper.add(header, BorderLayout.NORTH);
        wrapper.add(contentPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel buildWelcomePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);

        JPanel box = new JPanel();
        box.setOpaque(false);
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));

        JLabel emoji = new JLabel("🛒", SwingConstants.CENTER);
        emoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        emoji.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("Bienvenido al Sistema MS", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 26));
        title.setForeground(UITheme.TEXT_PRIMARY);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Selecciona una opción del menú para comenzar", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_BODY);
        sub.setForeground(UITheme.TEXT_MUTED);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        box.add(emoji);
        box.add(Box.createVerticalStrut(12));
        box.add(title);
        box.add(Box.createVerticalStrut(8));
        box.add(sub);

        panel.add(box);
        return panel;
    }
}
