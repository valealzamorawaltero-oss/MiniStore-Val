package gui;

import dao.ProductoDAO;
import model.Categoria;
import model.Producto;
import util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ProductosPanel extends JPanel {

    private ProductoDAO dao = new ProductoDAO();
    private DefaultTableModel tableModel;
    private JTable tabla;
    private JTextField txtBuscar, txtNombre, txtPrecio, txtCosto, txtStock, txtDescripcion;
    private JComboBox<Categoria> cmbCategoria;
    private JLabel lblStatus;
    private int selectedId = -1;

    private static final NumberFormat FMT = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));

    public ProductosPanel() {
        setOpaque(false);
        setLayout(new BorderLayout());
        initUI();
        cargarTabla(dao.getAll());
        avisarSiHayError();
    }

    private void initUI() {
        // ── Barra superior ────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout(12, 0));
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(16, 24, 12, 24));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchBar.setOpaque(false);

        txtBuscar = UITheme.styledField("Buscar producto…");
        txtBuscar.setPreferredSize(new Dimension(220, 36));
        txtBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { filtrar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { filtrar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filtrar(); }
        });

        // Combo categoría
        List<Categoria> cats = new ArrayList<>(dao.getCategorias());
        cats.add(0, new Categoria(0, "Todas las categorías"));
        JComboBox<Categoria> cmbFiltro = new JComboBox<>(cats.toArray(new Categoria[0]));
        cmbFiltro.setFont(UITheme.FONT_BODY);
        cmbFiltro.setBackground(UITheme.BG_CARD);
        cmbFiltro.setForeground(UITheme.TEXT_PRIMARY);
        cmbFiltro.setPreferredSize(new Dimension(180, 36));
        cmbFiltro.addActionListener(e -> filtrarCategoria((Categoria) cmbFiltro.getSelectedItem()));

        searchBar.add(txtBuscar);
        searchBar.add(cmbFiltro);

        JButton btnNuevo = UITheme.primaryButton("+ Nuevo Producto");
        btnNuevo.addActionListener(e -> limpiarFormulario());

        topBar.add(searchBar, BorderLayout.WEST);
        topBar.add(btnNuevo, BorderLayout.EAST);

        // ── Tabla ─────────────────────────────────────────────────
        String[] cols = {"ID", "Nombre", "Categoría", "Precio", "Stock", "Costo", "Descripción"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(tableModel);
        UITheme.styleTable(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(3).setCellRenderer(new PriceRenderer());
        tabla.getColumnModel().getColumn(4).setCellRenderer(new StockRenderer());
        tabla.getColumnModel().getColumn(5).setCellRenderer(new PriceRenderer());
        tabla.getColumnModel().getColumn(6).setPreferredWidth(220);

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                selectedId = (int) tableModel.getValueAt(row, 0);
                txtNombre.setText((String) tableModel.getValueAt(row, 1));
                String cat = (String) tableModel.getValueAt(row, 2);
                for (int i = 0; i < cmbCategoria.getItemCount(); i++)
                    if (cmbCategoria.getItemAt(i).getNombre().equals(cat)) cmbCategoria.setSelectedIndex(i);
                txtPrecio.setText(String.valueOf(tableModel.getValueAt(row, 3)));
                txtStock.setText(String.valueOf(tableModel.getValueAt(row, 4)));
                txtCosto.setText(String.valueOf(tableModel.getValueAt(row, 5)));
                Object desc = tableModel.getValueAt(row, 6);
                txtDescripcion.setText(desc == null ? "" : desc.toString());
            }
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setOpaque(false);
        scroll.getViewport().setBackground(UITheme.BG_CARD);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, UITheme.BORDER));

        // ── Formulario ─────────────────────────────────────────────
        JPanel formPanel = new JPanel();
        formPanel.setOpaque(false);
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, UITheme.BORDER),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel formTitle = new JLabel("Datos del Producto");
        formTitle.setFont(UITheme.FONT_SUBTITLE);
        formTitle.setForeground(UITheme.TEXT_PRIMARY);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        txtNombre = UITheme.styledField("Nombre del producto");
        txtPrecio = UITheme.styledField("0.00");
        txtCosto  = UITheme.styledField("0.00");
        txtStock  = UITheme.styledField("0");
        txtDescripcion = UITheme.styledField("Descripción breve (opcional)");
        cmbCategoria = new JComboBox<>(dao.getCategorias().toArray(new Categoria[0]));
        cmbCategoria.setFont(UITheme.FONT_BODY);
        cmbCategoria.setBackground(UITheme.BG_CARD);
        cmbCategoria.setForeground(UITheme.TEXT_PRIMARY);
        cmbCategoria.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmbCategoria.setAlignmentX(Component.LEFT_ALIGNMENT);

        for (JTextField f : new JTextField[]{txtNombre, txtPrecio, txtCosto, txtStock, txtDescripcion}) {
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        JButton btnGuardar  = UITheme.primaryButton("💾  Guardar");
        JButton btnEliminar = UITheme.dangerButton("🗑  Eliminar");
        for (JButton b : new JButton[]{btnGuardar, btnEliminar}) {
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        lblStatus = new JLabel(" ");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnGuardar.addActionListener(e -> guardar());
        btnEliminar.addActionListener(e -> eliminar());

        String[] fLabels = {"Nombre", "Categoría", "Precio venta (COP)", "Precio costo (COP)", "Stock", "Descripción (opcional)"};
        Component[] fComps = {txtNombre, cmbCategoria, txtPrecio, txtCosto, txtStock, txtDescripcion};

        formPanel.add(formTitle);
        formPanel.add(Box.createVerticalStrut(16));
        for (int i = 0; i < fLabels.length; i++) {
            JLabel lbl = new JLabel(fLabels[i]);
            lbl.setFont(UITheme.FONT_SMALL);
            lbl.setForeground(UITheme.TEXT_MUTED);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            formPanel.add(lbl);
            formPanel.add(Box.createVerticalStrut(3));
            formPanel.add(fComps[i]);
            formPanel.add(Box.createVerticalStrut(10));
        }
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnGuardar);
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnEliminar);
        formPanel.add(Box.createVerticalStrut(8));
        formPanel.add(lblStatus);
        formPanel.add(Box.createVerticalGlue());

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(scroll, BorderLayout.CENTER);
        // El formulario va dentro de un scroll: si la ventana es baja, se desplaza en vez de cortarse
        JScrollPane formScroll = new JScrollPane(formPanel,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        formScroll.setBorder(null);
        formScroll.setOpaque(false);
        formScroll.getViewport().setOpaque(false);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setPreferredSize(new Dimension(300, 0));
        center.add(formScroll, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }

    private void cargarTabla(List<Producto> lista) {
        tableModel.setRowCount(0);
        for (Producto p : lista)
            tableModel.addRow(new Object[]{p.getId(), p.getNombre(), p.getCategoria(), p.getPrecio(), p.getStock(), p.getPrecioCosto(), p.getDescripcion()});
    }

    private void filtrar() {
        String t = txtBuscar.getText().trim();
        cargarTabla(t.isEmpty() ? dao.getAll() : dao.buscarPorNombre(t));
    }

    private void filtrarCategoria(Categoria cat) {
        if (cat == null || cat.getId() == 0) cargarTabla(dao.getAll());
        else cargarTabla(dao.getByCategoria(cat.getId()));
    }

    private void guardar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) { status("⚠ El nombre es obligatorio", UITheme.WARNING); return; }
        try {
            double precio = Double.parseDouble(txtPrecio.getText().trim());
            String costoTxt = txtCosto.getText().trim();
            double costo  = costoTxt.isEmpty() ? 0 : Double.parseDouble(costoTxt);
            int stock     = Integer.parseInt(txtStock.getText().trim());
            Categoria cat = (Categoria) cmbCategoria.getSelectedItem();
            if (cat == null) { status("⚠ Selecciona una categoría", UITheme.WARNING); return; }
            if (precio < 0 || costo < 0 || stock < 0) {
                status("⚠ Precio, costo y stock no pueden ser negativos", UITheme.WARNING);
                return;
            }

            String descripcion = txtDescripcion.getText().trim();   // opcional: puede quedar vacía
            if (descripcion.length() > 200) {
                status("⚠ La descripción debe tener máximo 200 caracteres", UITheme.WARNING);
                return;
            }

            Producto p = new Producto(selectedId, nombre, cat.getId(), cat.getNombre(), precio, costo, stock, descripcion);
            boolean ok = selectedId < 0 ? dao.insertar(p) : dao.actualizar(p);
            if (ok) {
                status(selectedId < 0 ? "✓ Producto creado" : "✓ Producto actualizado", UITheme.SUCCESS);
                cargarTabla(dao.getAll());
                limpiarFormulario();
            } else {
                status("✗ " + dao.getUltimoError(), UITheme.DANGER);
            }
        } catch (NumberFormatException e) {
            status("⚠ Precio y stock deben ser numéricos", UITheme.WARNING);
        }
    }

    private void eliminar() {
        if (selectedId < 0) { status("⚠ Selecciona un producto", UITheme.WARNING); return; }
        int ok = JOptionPane.showConfirmDialog(this, "¿Eliminar producto?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION && dao.eliminar(selectedId)) {
            status("✓ Producto eliminado", UITheme.DANGER);
            cargarTabla(dao.getAll());
            limpiarFormulario();
        } else if (ok == JOptionPane.YES_OPTION) {
            status("✗ " + dao.getUltimoError(), UITheme.DANGER);
        }
    }

    private void limpiarFormulario() {
        selectedId = -1;
        txtNombre.setText(""); txtPrecio.setText(""); txtCosto.setText(""); txtStock.setText(""); txtDescripcion.setText("");
        if (cmbCategoria.getItemCount() > 0) cmbCategoria.setSelectedIndex(0);
        tabla.clearSelection();
        status(" ", UITheme.TEXT_MUTED);
    }

    private void avisarSiHayError() {
        if (dao.getUltimoError() != null)
            JOptionPane.showMessageDialog(this, "No se pudieron cargar los productos:\n" + dao.getUltimoError(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }

    private void status(String msg, Color color) {
        lblStatus.setText(msg);
        lblStatus.setForeground(color);
    }

    // ── Renderers ─────────────────────────────────────────────────
    static class PriceRenderer extends DefaultTableCellRenderer {
        PriceRenderer() { setHorizontalAlignment(RIGHT); }
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            super.getTableCellRendererComponent(t, v, s, f, r, c);
            setBackground(s ? new Color(99,102,241,80) : UITheme.BG_CARD);
            setForeground(UITheme.SUCCESS);
            setFont(UITheme.FONT_MONO);
            if (v instanceof Double)
                setText(FMT.format(v));
            return this;
        }
    }

    static class StockRenderer extends DefaultTableCellRenderer {
        StockRenderer() { setHorizontalAlignment(CENTER); }
        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            super.getTableCellRendererComponent(t, v, s, f, r, c);
            setBackground(s ? new Color(99,102,241,80) : UITheme.BG_CARD);
            int stock = v instanceof Integer ? (Integer) v : 0;
            setForeground(stock > 20 ? UITheme.SUCCESS : stock > 5 ? UITheme.WARNING : UITheme.DANGER);
            setFont(UITheme.FONT_BODY);
            return this;
        }
    }
}
