package gui;

import dao.UsuarioDAO;
import util.UITheme;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JLabel lblMensaje;

    public LoginFrame() {
        setTitle("Sistema de Gestión MS — Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setUndecorated(false);
        setResizable(false);
        initUI();
        pack();
        setLocationRelativeTo(null);
    }

    private void initUI() {
        // Panel principal con fondo degradado
        JPanel mainPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(
                    0, 0, UITheme.BG_DARK,
                    getWidth(), getHeight(), new Color(30, 20, 60)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Círculos decorativos difusos
                g2.setColor(new Color(99, 102, 241, 30));
                g2.fillOval(-60, -60, 280, 280);
                g2.setColor(new Color(99, 102, 241, 15));
                g2.fillOval(250, 200, 200, 200);
            }
        };
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setPreferredSize(new Dimension(420, 520));

        // Tarjeta central
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_PANEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(UITheme.BORDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(340, 400));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 24, 8, 24);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ícono / logo
        JLabel logo = new JLabel("🛒", SwingConstants.CENTER);
        logo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        gbc.insets = new Insets(28, 24, 4, 24);
        card.add(logo, gbc);

        // Título
        JLabel title = new JLabel("Sistema MS", SwingConstants.CENTER);
        title.setFont(UITheme.FONT_TITLE);
        title.setForeground(UITheme.TEXT_PRIMARY);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 24, 2, 24);
        card.add(title, gbc);

        // Subtítulo
        JLabel sub = new JLabel("Gestión de Clientes, Productos y Ventas", SwingConstants.CENTER);
        sub.setFont(UITheme.FONT_SMALL);
        sub.setForeground(UITheme.TEXT_MUTED);
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 24, 20, 24);
        card.add(sub, gbc);

        // Usuario
        gbc.gridy = 3;
        gbc.insets = new Insets(4, 24, 2, 24);
        JLabel lblU = new JLabel("Usuario");
        lblU.setFont(UITheme.FONT_SMALL);
        lblU.setForeground(UITheme.TEXT_MUTED);
        card.add(lblU, gbc);

        txtUsuario = UITheme.styledField("Usuario");
        gbc.gridy = 4;
        gbc.insets = new Insets(0, 24, 8, 24);
        card.add(txtUsuario, gbc);

        // Contraseña
        gbc.gridy = 5;
        gbc.insets = new Insets(4, 24, 2, 24);
        JLabel lblP = new JLabel("Contraseña");
        lblP.setFont(UITheme.FONT_SMALL);
        lblP.setForeground(UITheme.TEXT_MUTED);
        card.add(lblP, gbc);

        txtContrasena = UITheme.styledPassword();
        gbc.gridy = 6;
        gbc.insets = new Insets(0, 24, 12, 24);
        card.add(txtContrasena, gbc);

        // Mensaje de error
        lblMensaje = new JLabel(" ", SwingConstants.CENTER);
        lblMensaje.setFont(UITheme.FONT_SMALL);
        lblMensaje.setForeground(UITheme.DANGER);
        gbc.gridy = 7;
        gbc.insets = new Insets(0, 24, 4, 24);
        card.add(lblMensaje, gbc);

        // Botón login
        JButton btnLogin = UITheme.primaryButton("  Iniciar Sesión  ");
        btnLogin.setPreferredSize(new Dimension(292, 42));
        gbc.gridy = 8;
        gbc.insets = new Insets(4, 24, 24, 24);
        card.add(btnLogin, gbc);

        // Acción login
        ActionListener loginAction = e -> realizarLogin();
        btnLogin.addActionListener(loginAction);
        txtContrasena.addActionListener(loginAction);
        txtUsuario.addActionListener(loginAction);

        mainPanel.add(card);
        setContentPane(mainPanel);
    }

    private void realizarLogin() {
        String user = txtUsuario.getText().trim();
        String pass = new String(txtContrasena.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            lblMensaje.setForeground(UITheme.WARNING);
            lblMensaje.setText("⚠ Ingresa usuario y contraseña");
            return;
        }

        try {
            // Autenticación real contra la tabla "usuarios" de ministore
            String username = new UsuarioDAO().autenticar(user, pass);
            if (username != null) {
                lblMensaje.setForeground(UITheme.SUCCESS);
                lblMensaje.setText("✓ Conexión exitosa");
                final String usuarioValido = username;
                Timer timer = new Timer(600, e -> {
                    dispose();
                    new MainFrame(usuarioValido).setVisible(true);
                });
                timer.setRepeats(false);
                timer.start();
            } else {
                lblMensaje.setForeground(UITheme.DANGER);
                lblMensaje.setText("✗ Usuario o contraseña incorrectos");
                txtContrasena.setText("");
            }
        } catch (java.sql.SQLException ex) {
            lblMensaje.setForeground(UITheme.DANGER);
            lblMensaje.setText("✗ Sin conexión a la base de datos");
            JOptionPane.showMessageDialog(this,
                "No se pudo conectar con la base de datos ministore:\n" + ex.getMessage(),
                "Error de conexión", JOptionPane.ERROR_MESSAGE);
        }
    }
}
