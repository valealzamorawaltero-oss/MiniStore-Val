package gui;

import dao.ClienteDAO;
import dao.ProductoDAO;
import dao.VentaDAO;
import model.Cliente;
import model.ItemVenta;
import model.Producto;
import model.Venta;
import util.UITheme;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VentasPanel extends JPanel {

    private VentaDAO    ventaDAO    = new VentaDAO();
    private ClienteDAO  clienteDAO  = new ClienteDAO();
    private ProductoDAO productoDAO = new ProductoDAO();

    // Tabla de ventas ya registradas
    private DefaultTableModel tableModel;
    private JTable tabla;

    // Carrito de la venta en curso (varios productos)
    private final List<ItemVenta> carrito = new ArrayList<ItemVenta>();
    private DefaultTableModel carritoModel;
    private JTable tablaCarrito;

    private JComboBox<Cliente>  cmbCliente;
    private JComboBox<Producto> cmbProducto;
    private JSpinner spinCantidad;
    private JLabel lblTotal, lblGranTotal, lblStatus, lblDisponible;
    private int selectedId = -1;

    private static final NumberFormat FMT = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));

    public VentasPanel() {
        setOpaque(false);
        setLayout(new BorderLayout());
        initUI();
        cargarTabla();
        avisarSiHayError();
        // Al volver a esta pestaña, recarga clientes, productos (stock) y ventas desde la base de datos
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override public void componentShown(java.awt.event.ComponentEvent e) {
                recargarCombos();
                cargarTabla();
            }
        });
    }

    private void recargarCombos() {
        Cliente cSel  = (Cliente)  cmbCliente.getSelectedItem();
        Producto pSel = (Producto) cmbProducto.getSelectedItem();
        cmbCliente.setModel(new DefaultComboBoxModel<>(clienteDAO.getAll().toArray(new Cliente[0])));
        cmbProducto.setModel(new DefaultComboBoxModel<>(productoDAO.getAll().toArray(new Producto[0])));
        if (cSel != null)
            for (int i = 0; i < cmbCliente.getItemCount(); i++)
                if (cmbCliente.getItemAt(i).getId() == cSel.getId()) cmbCliente.setSelectedIndex(i);
        if (pSel != null)
            for (int i = 0; i < cmbProducto.getItemCount(); i++)
                if (cmbProducto.getItemAt(i).getId() == pSel.getId()) cmbProducto.setSelectedIndex(i);
        actualizarDisponible();
    }

    private void avisarSiHayError() {
        String err = ventaDAO.getUltimoError();
        if (err != null)
            JOptionPane.showMessageDialog(this, "No se pudieron cargar las ventas:\n" + err
                + "\n\nVerifica que existan las tablas ventas y detalle_venta (ver ventas.sql).",
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }

    private void initUI() {
        // ── KPI cards ────────────────────────────────────────────
        JPanel kpiBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 0));
        kpiBar.setOpaque(false);
        kpiBar.setBorder(BorderFactory.createEmptyBorder(16, 24, 8, 24));

        lblGranTotal = new JLabel("Total ventas: $0");
        kpiBar.add(buildKpiCard("💰", "Total Ventas", lblGranTotal));

        // ── Tabla de ventas (una fila por producto vendido) ──────
        String[] cols = {"ID", "Cliente", "Producto", "Cant.", "Subtotal", "Fecha"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(tableModel);
        UITheme.styleTable(tabla);
        tabla.getColumnModel().getColumn(0).setMaxWidth(50);
        tabla.getColumnModel().getColumn(3).setMaxWidth(60);
        tabla.getColumnModel().getColumn(4).setCellRenderer(new ProductosPanel.PriceRenderer());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0)
                selectedId = (int) tableModel.getValueAt(tabla.getSelectedRow(), 0);
        });

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setOpaque(false);
        scroll.getViewport().setBackground(UITheme.BG_CARD);
        scroll.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, UITheme.BORDER));

        // ── Formulario de nueva venta ─────────────────────────────
        JPanel formPanel = new PanelDesplazable();
        formPanel.setOpaque(false);
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, UITheme.BORDER),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        JLabel formTitle = new JLabel("Nueva Venta");
        formTitle.setFont(UITheme.FONT_SUBTITLE);
        formTitle.setForeground(UITheme.TEXT_PRIMARY);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Combo cliente
        List<Cliente> clientes = clienteDAO.getAll();
        cmbCliente = new JComboBox<>(clientes.toArray(new Cliente[0]));
        styleCombo(cmbCliente);

        // Combo producto
        List<Producto> productos = productoDAO.getAll();
        cmbProducto = new JComboBox<>(productos.toArray(new Producto[0]));
        styleCombo(cmbProducto);
        cmbProducto.addActionListener(e -> actualizarDisponible());

        // Stock disponible del producto elegido
        lblDisponible = new JLabel(" ");
        lblDisponible.setFont(UITheme.FONT_SMALL);
        lblDisponible.setForeground(UITheme.TEXT_MUTED);
        lblDisponible.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Spinner cantidad
        spinCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 9999, 1));
        spinCantidad.setFont(UITheme.FONT_BODY);
        ((JSpinner.DefaultEditor) spinCantidad.getEditor()).getTextField().setBackground(UITheme.BG_CARD);
        ((JSpinner.DefaultEditor) spinCantidad.getEditor()).getTextField().setForeground(UITheme.TEXT_PRIMARY);

        JButton btnAgregar = UITheme.primaryButton("＋ Agregar");
        btnAgregar.addActionListener(e -> agregarAlCarrito());

        JPanel filaAgregar = new JPanel(new BorderLayout(8, 0));
        filaAgregar.setOpaque(false);
        filaAgregar.add(spinCantidad, BorderLayout.CENTER);
        filaAgregar.add(btnAgregar, BorderLayout.EAST);
        filaAgregar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        filaAgregar.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Carrito (productos de esta venta)
        carritoModel = new DefaultTableModel(new String[]{"Producto", "Cant.", "Subtotal"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaCarrito = new JTable(carritoModel);
        UITheme.styleTable(tablaCarrito);
        tablaCarrito.getColumnModel().getColumn(1).setMaxWidth(45);
        tablaCarrito.getColumnModel().getColumn(2).setPreferredWidth(90);
        tablaCarrito.getColumnModel().getColumn(2).setCellRenderer(new ProductosPanel.PriceRenderer());

        JScrollPane scrollCarrito = new JScrollPane(tablaCarrito);
        scrollCarrito.setOpaque(false);
        scrollCarrito.getViewport().setBackground(UITheme.BG_CARD);
        scrollCarrito.setBorder(BorderFactory.createLineBorder(UITheme.BORDER, 1));
        scrollCarrito.setPreferredSize(new Dimension(260, 130));
        scrollCarrito.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        scrollCarrito.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btnQuitar = UITheme.dangerButton("Quitar");
        JButton btnVaciar = UITheme.dangerButton("Vaciar");
        btnQuitar.addActionListener(e -> quitarDelCarrito());
        btnVaciar.addActionListener(e -> vaciarCarrito());
        JPanel filaQuitar = new JPanel(new GridLayout(1, 2, 8, 0));
        filaQuitar.setOpaque(false);
        filaQuitar.add(btnQuitar);
        filaQuitar.add(btnVaciar);
        filaQuitar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        filaQuitar.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Label total
        lblTotal = new JLabel("Total: $0");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotal.setForeground(UITheme.SUCCESS);
        lblTotal.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btnRegistrar = UITheme.successButton("✔  Registrar Venta");
        JButton btnEliminar  = UITheme.dangerButton("🗑  Eliminar venta de la tabla");
        for (JButton b : new JButton[]{btnRegistrar, btnEliminar}) {
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        lblStatus = new JLabel(" ");
        lblStatus.setFont(UITheme.FONT_SMALL);
        lblStatus.setAlignmentX(Component.LEFT_ALIGNMENT);

        btnRegistrar.addActionListener(e -> registrarVenta());
        btnEliminar.addActionListener(e -> eliminarVenta());

        // Card total
        // Fondo translúcido: el panel NO debe ser opaco, o el texto anterior queda dibujado debajo del nuevo
        JPanel totalCard = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(getBackground());
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        totalCard.setOpaque(false);
        totalCard.setBackground(new Color(34, 197, 94, 20));
        totalCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(UITheme.SUCCESS, 1),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        totalCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        totalCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        totalCard.add(lblTotal, BorderLayout.CENTER);

        formPanel.add(formTitle);
        formPanel.add(Box.createVerticalStrut(14));
        formPanel.add(etiqueta("Cliente"));
        formPanel.add(Box.createVerticalStrut(3));
        formPanel.add(cmbCliente);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(etiqueta("Producto"));
        formPanel.add(Box.createVerticalStrut(3));
        formPanel.add(cmbProducto);
        formPanel.add(Box.createVerticalStrut(2));
        formPanel.add(lblDisponible);
        formPanel.add(Box.createVerticalStrut(8));
        formPanel.add(etiqueta("Cantidad"));
        formPanel.add(Box.createVerticalStrut(3));
        formPanel.add(filaAgregar);
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(etiqueta("Productos de esta venta"));
        formPanel.add(Box.createVerticalStrut(3));
        formPanel.add(scrollCarrito);
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(filaQuitar);
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(totalCard);
        formPanel.add(Box.createVerticalStrut(12));
        formPanel.add(btnRegistrar);
        formPanel.add(Box.createVerticalStrut(6));
        formPanel.add(btnEliminar);
        formPanel.add(Box.createVerticalStrut(8));
        formPanel.add(lblStatus);
        formPanel.add(Box.createVerticalGlue());

        // El formulario va dentro de un scroll: si la ventana es baja, se desplaza en vez de cortarse
        JScrollPane formScroll = new JScrollPane(formPanel,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        formScroll.setBorder(null);
        formScroll.setOpaque(false);
        formScroll.getViewport().setOpaque(false);
        formScroll.getVerticalScrollBar().setUnitIncrement(16);
        formScroll.setPreferredSize(new Dimension(340, 0));

        // ── Layout central ────────────────────────────────────────
        JPanel tableArea = new JPanel(new BorderLayout());
        tableArea.setOpaque(false);
        tableArea.add(kpiBar, BorderLayout.NORTH);
        tableArea.add(scroll, BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.add(tableArea,  BorderLayout.CENTER);
        center.add(formScroll, BorderLayout.EAST);

        add(center, BorderLayout.CENTER);

        refrescarCarrito();
        actualizarDisponible();
    }

    /** Panel que siempre toma el ancho disponible del scroll (nunca se sale por la derecha). */
    private static class PanelDesplazable extends JPanel implements Scrollable {
        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle r, int orientation, int direction) { return 16; }
        @Override public int getScrollableBlockIncrement(Rectangle r, int orientation, int direction) { return 64; }
        @Override public boolean getScrollableTracksViewportWidth()  { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }

    private JLabel etiqueta(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(UITheme.FONT_SMALL);
        lbl.setForeground(UITheme.TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JPanel buildKpiCard(String icon, String label, JLabel valueLabel) {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UITheme.BG_CARD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.setColor(UITheme.BORDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 12, 12);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 8));
        card.setPreferredSize(new Dimension(280, 64));

        JLabel ico = new JLabel(icon);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));

        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        JLabel lbl = new JLabel(label);
        lbl.setFont(UITheme.FONT_SMALL);
        lbl.setForeground(UITheme.TEXT_MUTED);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 15));
        valueLabel.setForeground(UITheme.SUCCESS);
        text.add(lbl);
        text.add(valueLabel);

        card.add(ico);
        card.add(text);
        return card;
    }

    private void styleCombo(JComboBox<?> cmb) {
        cmb.setFont(UITheme.FONT_BODY);
        cmb.setBackground(UITheme.BG_CARD);
        cmb.setForeground(UITheme.TEXT_PRIMARY);
        cmb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmb.setAlignmentX(Component.LEFT_ALIGNMENT);
    }

    // ── Carrito ──────────────────────────────────────────────────
    private int cantidadEnCarrito(int productoId) {
        int n = 0;
        for (ItemVenta it : carrito) if (it.getProductoId() == productoId) n += it.getCantidad();
        return n;
    }

    /** Muestra cuánto stock queda disponible del producto elegido (descontando lo ya agregado). */
    private void actualizarDisponible() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) { lblDisponible.setText(" "); return; }
        int disponible = p.getStock() - cantidadEnCarrito(p.getId());
        lblDisponible.setText("Precio: " + FMT.format(p.getPrecio()) + "   |   Disponible: " + disponible);
    }

    private void agregarAlCarrito() {
        Producto p = (Producto) cmbProducto.getSelectedItem();
        if (p == null) { status("⚠ Selecciona un producto", UITheme.WARNING); return; }

        int cant = (Integer) spinCantidad.getValue();
        int yaEnCarrito = cantidadEnCarrito(p.getId());
        int disponible = p.getStock() - yaEnCarrito;
        if (cant > disponible) {
            status("⚠ Stock insuficiente de \"" + p.getNombre() + "\" (disponible: " + Math.max(disponible, 0) + ")",
                   UITheme.WARNING);
            return;
        }

        boolean sumado = false;
        for (ItemVenta it : carrito) {
            if (it.getProductoId() == p.getId()) {
                it.setCantidad(it.getCantidad() + cant);
                sumado = true;
                break;
            }
        }
        if (!sumado) carrito.add(new ItemVenta(p.getId(), p.getNombre(), cant, p.getPrecio()));

        spinCantidad.setValue(1);
        refrescarCarrito();
        status("✓ Agregado: " + cant + " x " + p.getNombre(), UITheme.SUCCESS);
    }

    private void quitarDelCarrito() {
        int fila = tablaCarrito.getSelectedRow();
        if (fila < 0) { status("⚠ Selecciona un producto del carrito", UITheme.WARNING); return; }
        carrito.remove(fila);
        refrescarCarrito();
        status("Producto quitado del carrito", UITheme.TEXT_MUTED);
    }

    private void vaciarCarrito() {
        carrito.clear();
        refrescarCarrito();
        status(" ", UITheme.TEXT_MUTED);
    }

    private void refrescarCarrito() {
        carritoModel.setRowCount(0);
        double total = 0;
        for (ItemVenta it : carrito) {
            carritoModel.addRow(new Object[]{it.getProductoNombre(), it.getCantidad(), it.getSubtotal()});
            total += it.getSubtotal();
        }
        lblTotal.setText("Total: " + FMT.format(total));
        actualizarDisponible();
    }

    // ── Ventas ───────────────────────────────────────────────────
    private void cargarTabla() {
        tableModel.setRowCount(0);
        for (Venta v : ventaDAO.getAll())
            tableModel.addRow(new Object[]{
                v.getId(), v.getClienteNombre(), v.getProductoNombre(),
                v.getCantidad(), v.getTotal(), v.getFecha().toString()
            });
        lblGranTotal.setText(FMT.format(ventaDAO.getTotalVentas()));
    }

    private void registrarVenta() {
        Cliente c = (Cliente) cmbCliente.getSelectedItem();
        if (c == null) { status("⚠ Selecciona un cliente", UITheme.WARNING); return; }
        if (carrito.isEmpty()) { status("⚠ Agrega al menos un producto a la venta", UITheme.WARNING); return; }

        int idVenta = ventaDAO.registrarVenta(c.getId(), new ArrayList<ItemVenta>(carrito));
        if (idVenta > 0) {
            status("✓ Venta N° " + ventaDAO.getUltimoNumeroVenta() + " registrada: "
                   + FMT.format(ventaDAO.getUltimoTotal()), UITheme.SUCCESS);
            carrito.clear();
            refrescarCarrito();
            cargarTabla();
            recargarCombos();       // el stock de los productos cambió
        } else {
            status("✗ " + ventaDAO.getUltimoError(), UITheme.DANGER);
        }
    }

    private void eliminarVenta() {
        if (selectedId < 0) { status("⚠ Selecciona una venta en la tabla", UITheme.WARNING); return; }
        int ok = JOptionPane.showConfirmDialog(this,
            "¿Eliminar la venta #" + selectedId + " completa (todos sus productos)?\n"
            + "Se devolverá el stock de sus productos.",
            "Confirmar", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION && ventaDAO.eliminar(selectedId)) {
            status("✓ Venta eliminada", UITheme.DANGER);
            cargarTabla();
            recargarCombos();
            selectedId = -1;
        } else if (ok == JOptionPane.YES_OPTION) {
            status("✗ " + ventaDAO.getUltimoError(), UITheme.DANGER);
        }
    }

    private void status(String msg, Color color) {
        lblStatus.setText("<html><body style='width:240px'>" + msg.replace("&", "&amp;").replace("<", "&lt;") + "</body></html>");
        lblStatus.setForeground(color);
    }
}
