package util;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * Conexión a la base de datos MySQL "ministore".
 * Edita aquí el usuario y la contraseña si cambian.
 *
 * El driver (mysql-connector-j-*.jar) se busca primero en el classpath del proyecto y, si el IDE
 * no lo incluyó, se carga automáticamente desde la carpeta "lib" del proyecto.
 * La conexión es compartida: los DAO NO deben cerrarla.
 */
public class DBConnection {

    // ── Datos de conexión ────────────────────────────────────────
    private static final String HOST     = "localhost";
    private static final String PUERTO   = "3306";
    private static final String BASE     = "ministore";
    private static final String USER     = "root";
    private static final String PASSWORD = "1930";
    // ─────────────────────────────────────────────────────────────

    private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";

    private static final String URL = "jdbc:mysql://" + HOST + ":" + PUERTO + "/" + BASE
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&characterEncoding=UTF-8";

    private static Connection connection = null;
    private static Driver driver = null;

    static {
        // Cierra la conexión al salir de la aplicación
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override public void run() { closeConnection(); }
        }));
    }

    /** Devuelve la conexión compartida (la reabre si se cayó). */
    public static synchronized Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed() || !connection.isValid(2)) {
            Properties props = new Properties();
            props.setProperty("user", USER);
            props.setProperty("password", PASSWORD);
            Connection c = cargarDriver().connect(URL, props);
            if (c == null) throw new SQLException("El driver no aceptó la URL de conexión: " + URL);
            connection = c;
        }
        return connection;
    }

    public static synchronized void closeConnection() {
        if (connection != null) {
            try { connection.close(); } catch (SQLException e) { e.printStackTrace(); }
            connection = null;
        }
    }

    // ── Carga del driver ─────────────────────────────────────────
    private static Driver cargarDriver() throws SQLException {
        if (driver != null) return driver;

        // 1) Normal: el .jar ya está en el classpath del proyecto
        try {
            driver = (Driver) Class.forName(DRIVER_CLASS).getDeclaredConstructor().newInstance();
            return driver;
        } catch (ClassNotFoundException e) {
            // se intenta cargar desde la carpeta lib
        } catch (Exception e) {
            throw new SQLException("No se pudo iniciar el driver MySQL: " + e, e);
        }

        // 2) Respaldo: buscar mysql-connector-j*.jar en la carpeta lib del proyecto
        List<String> buscadas = new ArrayList<String>();
        File jar = buscarJar(buscadas);
        if (jar == null) {
            throw new SQLException("No se encontró el driver MySQL (mysql-connector-j-*.jar).\n"
                + "Copia el .jar a la carpeta \"lib\" del proyecto. Carpetas revisadas:\n  "
                + String.join("\n  ", buscadas));
        }
        try {
            URLClassLoader cargador = new URLClassLoader(new URL[]{jar.toURI().toURL()},
                                                         DBConnection.class.getClassLoader());
            driver = (Driver) Class.forName(DRIVER_CLASS, true, cargador).getDeclaredConstructor().newInstance();
            return driver;
        } catch (Exception e) {
            throw new SQLException("No se pudo cargar el driver desde " + jar + ": " + e, e);
        }
    }

    private static File buscarJar(List<String> buscadas) {
        List<File> bases = new ArrayList<File>();

        // Carpeta desde donde se ejecuta el programa (NetBeans usa la carpeta del proyecto)
        bases.add(new File(System.getProperty("user.dir", ".")));

        // Carpeta de las clases / del .jar y sus carpetas padre (hasta 5 niveles)
        try {
            File ubicacion = new File(DBConnection.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            File dir = ubicacion.isDirectory() ? ubicacion : ubicacion.getParentFile();
            for (int i = 0; i < 5 && dir != null; i++) {
                bases.add(dir);
                dir = dir.getParentFile();
            }
        } catch (Exception ignorado) { }

        // Carpetas "lib" candidatas: la de cada base y, para la carpeta de ejecución, también la
        // de sus subcarpetas directas (por si el zip se descomprimió dentro de otra carpeta).
        List<File> libs = new ArrayList<File>();
        for (File base : bases) {
            libs.add(new File(base, "lib"));
            buscadas.add(new File(base, "lib").getAbsolutePath());
        }
        File ejecucion = bases.get(0);
        File[] hijos = ejecucion.listFiles();
        if (hijos != null) {
            Arrays.sort(hijos);
            for (File h : hijos)
                if (h.isDirectory()) libs.add(new File(h, "lib"));
        }
        buscadas.add(new File(ejecucion, "<subcarpeta>" + File.separator + "lib").getAbsolutePath());

        for (File lib : libs) {
            File[] jars = lib.listFiles();
            if (jars == null) continue;
            Arrays.sort(jars);
            File mejor = null;
            for (File f : jars) {
                String n = f.getName().toLowerCase();
                if (n.startsWith("mysql-connector") && n.endsWith(".jar")) mejor = f;  // la versión más alta
            }
            if (mejor != null) return mejor;
        }
        return null;
    }
}
