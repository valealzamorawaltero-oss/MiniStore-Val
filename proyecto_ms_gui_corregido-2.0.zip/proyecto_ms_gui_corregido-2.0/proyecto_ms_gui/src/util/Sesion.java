package util;

/** Usuario que inició sesión (se guarda como vendedor en cada venta). */
public class Sesion {
    private static int usuarioId = -1;
    private static String username;

    public static void iniciar(int id, String user) { usuarioId = id; username = user; }
    public static void cerrar()                     { usuarioId = -1; username = null; }

    public static int getUsuarioId()   { return usuarioId; }
    public static String getUsername() { return username; }
    public static boolean activa()     { return usuarioId > 0; }
}
