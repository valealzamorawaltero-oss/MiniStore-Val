-- Ejecutar en la base "ministore" SOLO si estas tablas no existen todavía.
-- (Sin claves foráneas para evitar conflictos de tipos con tus tablas actuales.)

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ventas')
BEGIN
    CREATE TABLE ventas (
        id_venta     INT IDENTITY(1,1) PRIMARY KEY,
        numero_venta INT NOT NULL UNIQUE,
        id_cliente   INT NOT NULL,
        id_usuario   INT NOT NULL,   -- usuario (vendedor) que registró la venta
        fecha        DATETIME2 DEFAULT (GETDATE()),
        total        DECIMAL(12,2) NOT NULL
    );
END;

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'detalle_venta')
BEGIN
    CREATE TABLE detalle_venta (
        id_detalle      INT IDENTITY(1,1) PRIMARY KEY,
        id_venta        INT NOT NULL,
        id_producto     INT NOT NULL,
        cantidad        INT NOT NULL,
        precio_unitario DECIMAL(12,2) NOT NULL,
        subtotal        DECIMAL(12,2) NOT NULL
    );
END;

